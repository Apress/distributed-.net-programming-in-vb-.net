Public Class SimpleMath

   Public Shared Function Add(n1 as Integer, n2 as Integer)
      Return n1 + n2
   End Function

   Public Shared Function Subtract(n1 as Integer, n2 as Integer)
      Return n1 - n2
   End Function
    
End Class
